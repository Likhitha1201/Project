# ---- IMPORT LIBRARIES 


import streamlit as st

import pandas as pd
import os
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
import base64

import csv
import sys    
import streamlit as st
import cv2
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import matplotlib.pyplot as plt 

from tkinter.filedialog import askopenfilename
from tensorflow.keras.models import Sequential

import cv2
from skimage.io import imshow

import os
import argparse
import numpy as np
import numpy
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import cv2
    
    
# --------------- BACKGROUND IMAGE 


st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:36px;">{"  Suspicious Activity Recognition "}</h1>', unsafe_allow_html=True)


def add_bg_from_local(image_file):
    with open(image_file, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    st.markdown(
    f"""
    <style>
    .stApp {{
        background-image: url(data:image/{"png"};base64,{encoded_string.decode()});
        background-size: cover
    }}
    </style>
    """,
    unsafe_allow_html=True
    )
add_bg_from_local('1.avif')   


# ============= READ INPUT VIDEO ================

# st.title(" Suspicious Activity Recognition")

uploaded_file = st.file_uploader("Choose a video...", type=["mp4", "mpeg"])

# st.text(uploaded_file)   

 
# aa = st.button(" Upload Video ")

if uploaded_file is None:
    st.markdown(f'<h1 style="color:#FFFFFF;font-size:18px;">{"Please Upload Video"}</h1>', unsafe_allow_html=True)

    # st.text("Please Upload Video")
    
else:
    st.text("Uploaded")
    
    with open(os.path.join("tempDir",uploaded_file.name),"wb") as f:
          f.write(uploaded_file.getbuffer())
    st.success("Video Saved Successfully")    
    
    
    # with open(os.path.join("tempDir",uploaded_file.name),"wb") as f:
    #      f.write(uploaded_file.getbuffer())
    # st.success("Video Saved Successfully")

    aa = uploaded_file.name
    
    text_file = open("Filename", "w")
     
    #write string to file
    text_file.write(aa)
     
    #close file
    text_file.close()    


    video_file = open("Dataset3/" + aa, 'rb')
    video_bytes = video_file.read()
    # tk=str(U_P1)
    # tk=float(tk[0:2])
    st.video(video_bytes)
    


# if aa:


    # Open the video file.
    aa = uploaded_file.name
    path = 'Dataset3/'
    inp = path+aa
    st.text(inp)
    # filename = askopenfilename()
    cap = cv2.VideoCapture(path+aa)
    # cap = cv2.VideoCapture(filename)
    Frames_all = []
    # Loop over the frames in the video.
    while True:
        # Read the next frame from the video.
        ret, frame = cap.read()
    
        # If the frame is not read successfully, break from the loop.
        if not ret:
            break
    
        # Convert the frame to grayscale.
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
        # Display the frame.
        cv2.imshow('Frame', frame)
        Frames_all.append(frame)
        # Wait for a key press.
        key = cv2.waitKey(1)
    
        # If the key pressed is `q`, break from the loop.
        if key == ord('q'):
            break
    
    # Close the video file.
    cap.release()
    
    # Destroy all windows created by OpenCV.
    cv2.destroyAllWindows()
    
    
    # ===================== CONVERT VIDO INTO FRAMES ===================
    
    
    Testfeature = []
    
    for iiij in range(0,len(Frames_all)):
        
        img1 = Frames_all[iiij]
        
        plt.imshow(img1)
        plt.title('ORIGINAL IMAGE')
        plt.show()
        
        #
        # PRE-PROCESSING
        
        h1=512
        w1=512
        
        dimension = (w1, h1) 
        resized_image1 = cv2.resize(img1,(h1,w1))
        
        fig = plt.figure()
        plt.title('RESIZED IMAGE')
        plt.imshow(resized_image1)
        plt.show()
        
        
        # ===== FEATURE EXTRACTION ====
        
        
        #=== MEAN STD DEVIATION ===
        
        mean_val = np.mean(resized_image1)
        median_val = np.median(resized_image1)
        var_val = np.var(resized_image1)
        features_extraction = [mean_val,median_val,var_val]
        
        print("====================================")
        print("        Feature Extraction          ")
        print("====================================")
        print()
        print(features_extraction)    
        
        
        # ==== LBP =========
        
        import cv2
        import numpy as np
        from matplotlib import pyplot as plt
           
              
        def find_pixel(imgg, center, x, y):
            new_value = 0
            try:
                if imgg[x][y] >= center:
                    new_value = 1
            except:
                pass
            return new_value
           
        # Function for calculating LBP
        def lbp_calculated_pixel(imgg, x, y):
            center = imgg[x][y]
            val_ar = []
            val_ar.append(find_pixel(imgg, center, x-1, y-1))
            val_ar.append(find_pixel(imgg, center, x-1, y))
            val_ar.append(find_pixel(imgg, center, x-1, y + 1))
            val_ar.append(find_pixel(imgg, center, x, y + 1))
            val_ar.append(find_pixel(imgg, center, x + 1, y + 1))
            val_ar.append(find_pixel(imgg, center, x + 1, y))
            val_ar.append(find_pixel(imgg, center, x + 1, y-1))
            val_ar.append(find_pixel(imgg, center, x, y-1))
            power_value = [1, 2, 4, 8, 16, 32, 64, 128]
            val = 0
            for i in range(len(val_ar)):
                val += val_ar[i] * power_value[i]
            return val
           
           
        height, width, _ = img1.shape
           
        img_gray_conv = cv2.cvtColor(img1,cv2.COLOR_BGR2GRAY)
           
        img_lbp = np.zeros((height, width),np.uint8)
           
        for i in range(0, height):
            for j in range(0, width):
                img_lbp[i, j] = lbp_calculated_pixel(img_gray_conv, i, j)
        
        plt.imshow(img_lbp, cmap ="gray")
        plt.title("LBP")
        plt.show()    
            
        # =============== GLCM ===================
    
        
        from skimage.feature import graycomatrix, graycoprops
        
        # -- FEATURE EXTRACTION
        # Face
        
        PATCH_SIZE = 21
        
        image = resized_image1[:,:,0]
        image = cv2.resize(image,(768,1024))
        
        # select some patches from foreground and background
        
        grass_locations = [(280, 454), (342, 223), (444, 192), (455, 455)]
        grass_patches = []
        for loc in grass_locations:
            grass_patches.append(image[loc[0]:loc[0] + PATCH_SIZE,
                                        loc[1]:loc[1] + PATCH_SIZE])
        
        # select some patches from sky areas of the image
        sky_locations = [(38, 34), (139, 28), (37, 437), (145, 379)]
        sky_patches = []
        for loc in sky_locations:
            sky_patches.append(image[loc[0]:loc[0] + PATCH_SIZE,
                                      loc[1]:loc[1] + PATCH_SIZE])
        
        # compute some GLCM properties each patch
        xs = []
        ys = []
        for patch in (grass_patches + sky_patches):
            glcm = graycomatrix(patch, distances=[5], angles=[0], levels=256,symmetric=True)
            xs.append(graycoprops(glcm, 'dissimilarity')[0, 0])
            ys.append(graycoprops(glcm, 'correlation')[0, 0])
        
        # create the figure
        fig = plt.figure(figsize=(8, 8))
        
        # display original image with locations of patches
        ax = fig.add_subplot(3, 2, 1)
        ax.imshow(image, cmap=plt.cm.gray,
                  vmin=0, vmax=255)
        for (y, x) in grass_locations:
            ax.plot(x + PATCH_SIZE / 2, y + PATCH_SIZE / 2, 'gs')
        for (y, x) in sky_locations:
            ax.plot(x + PATCH_SIZE / 2, y + PATCH_SIZE / 2, 'bs')
        ax.set_xlabel('Original Image')
        ax.set_xticks([])
        ax.set_yticks([])
        ax.axis('image')
        
        # for each patch, plot (dissimilarity, correlation)
        ax = fig.add_subplot(3, 2, 2)
        ax.plot(xs[:len(grass_patches)], ys[:len(grass_patches)], 'go',
                label='Region 1')
        ax.plot(xs[len(grass_patches):], ys[len(grass_patches):], 'bo',
                label='Region 2')
        ax.set_xlabel('Feature Index')
        ax.set_ylabel('Feature Points')
        ax.legend()
        
        # display the image patches
        for i, patch in enumerate(grass_patches):
            ax = fig.add_subplot(3, len(grass_patches), len(grass_patches)*1 + i + 1)
            ax.imshow(patch, cmap=plt.cm.gray,
                      vmin=0, vmax=255)
            ax.set_xlabel('Region 1 %d' % (i + 1))
        
        for i, patch in enumerate(sky_patches):
            ax = fig.add_subplot(3, len(sky_patches), len(sky_patches)*2 + i + 1)
            ax.imshow(patch, cmap=plt.cm.gray,
                      vmin=0, vmax=255)
            ax.set_xlabel('Region 2 %d' % (i + 1))
        
        
        # display the patches and plot
        fig.suptitle('co-occurrence matrix features', fontsize=14, y=1.05)
        plt.tight_layout()
        plt.show()
        
        sky_patches0 = np.mean(sky_patches[0])
        sky_patches1 = np.mean(sky_patches[1])
        sky_patches2 = np.mean(sky_patches[2])
        sky_patches3 = np.mean(sky_patches[3])
        
        
        Glcm_fea2 = [sky_patches0,sky_patches1,sky_patches2,sky_patches3]
        
        Testfeature.append(Glcm_fea2)
    
    
      # ================== TRAIN FEATURES =================
    
    
    import pickle
    with open('Train_Features_7.pickle', 'rb') as f:
        Train_features = pickle.load(f)
    
    y_trains = np.arange(0,2120)
    y_trains[0:60] = 1   # Alert
    y_trains[60:180] = 2  # Robbery
    y_trains[180:300] = 3  # Snatching
    y_trains[300:390] = 4  # Fighting
    y_trains[390:420] = 5  # Stealing
    
    
    y_trains[420:480] = 6  # Stealing
    y_trains[480:540] = 7  # Murder
    y_trains[540:784] = 8  # Robbery
    
    y_trains[784:880] = 9  # Gunshoot
    y_trains[880:1020] = 10  # Snatching
    y_trains[1020:1290] = 11  # Pickpocket
    y_trains[1290:1440] = 12 # Snatching
    y_trains[1440:1560] = 13 # Robbery
    
    
    y_trains[1560:1680] = 14 # Kidnaping
    y_trains[1680:1780] = 15 # Robbery
    y_trains[1780:1890] = 16 # Robbery 
    y_trains[1890:2120] = 17 # Accident
    
    # ==================== CLASSIFICATION ========================
    
    # === test and train ===
    
    import os 
    
    from sklearn.model_selection import train_test_split
    
    abu_data = os.listdir('Alert/')
    
    arrest_data = os.listdir('Robbery/')
    
    arson_data = os.listdir('Snatching/')
    
    fight_data = os.listdir('Fighting/')
    
    rob_data = os.listdir('Stealing/')
    
    rob_data = os.listdir('Stealing/')
    
    fight_data = os.listdir('Murder/')
    
    steal_data = os.listdir('Robbery/')
    
    road_data = os.listdir('Gunshoot/')
    
    arson_data = os.listdir('Snatching/')
    
    exp_data = os.listdir('Pickpocket/')
    
    rob_data = os.listdir('Snatching/')
    
    shop_data = os.listdir('Robbery/')
    
    road_data = os.listdir('Kidnaping/')
    
    exp_data = os.listdir('Robbery/')
    
    road_data = os.listdir('Robbery/')

    road_data = os.listdir('Accident/')
    
    
    dot1= []
    labels1 = []
    for img in abu_data:
            # print(img)
            img_1 = cv2.imread('Alert' + "/" + img)
            img_1 = cv2.resize(img_1,((50, 50)))
            
            dot1.append(np.array(img_1))
            labels1.append(0)
    
            
    for img in arrest_data:
        try:
            img_2 = cv2.imread('Robbery'+ "/" + img)
            img_2 = cv2.resize(img_2,((50, 50)))
    
                
            dot1.append(np.array(img_2))
            labels1.append(1)
        except:
            None
    
    
    
    
    for img in arson_data:
        try:
            img_2 = cv2.imread('Snatching'+ "/" + img)
            img_2 = cv2.resize(img_2,((50, 50)))
    
                
            dot1.append(np.array(img_2))
            labels1.append(2)
        except:
            None
            
      
    
    for img in fight_data:
        try:
            img_2 = cv2.imread('Fighting'+ "/" + img)
            img_2 = cv2.resize(img_2,((50, 50)))
    
    
            dot1.append(np.array(img_2))
            labels1.append(3)
        except:
            None
    
    
    
    
    for img in rob_data:
        try:
            img_2 = cv2.imread('Stealing'+ "/" + img)
            img_2 = cv2.resize(img_2,((50, 50)))
    
    
            dot1.append(np.array(img_2))
            labels1.append(4)
        except:
            None
            
    
    for img in rob_data:
        try:
            img_2 = cv2.imread('Stealing'+"/"+ img)
            img_2 = cv2.resize(img_2,((50, 50)))
    
    
            dot1.append(np.array(img_2))
            labels1.append(5)
        except:
            None
            
            for img in fight_data:
                try:
                    img_2 = cv2.imread('Murder'+"/"+ img)
                    img_2 = cv2.resize(img_2,((50, 50)))
            
                    dot1.append(np.array(img_2))
                    labels1.append(6)
                except:
                    None
            
    
    for img in steal_data:
        try:
            img_2 = cv2.imread('Robbery'+"/"+img)
            img_2 = cv2.resize(img_2,((50, 50)))
    
            dot1.append(np.array(img_2))
            labels1.append(7)
        except:
            None
            
            
                
        for img in road_data:
            try:
                img_2 = cv2.imread('Gunshoot'+ "/" + img)
                img_2 = cv2.resize(img_2,((50, 50)))
        
                dot1.append(np.array(img_2))
                labels1.append(8)
            except:
                None
            
            
            
        for img in arson_data:
            try:
                img_2 = cv2.imread('Snatching'+"/" + img)
                img_2 = cv2.resize(img_2,((50, 50)))
        
                dot1.append(np.array(img_2))
                labels1.append(9)
            except:
                None
            
            
            
            for img in exp_data:
                try:
                    img_2 = cv2.imread('Pickpocket'+ "/" + img)
                    img_2 = cv2.resize(img_2,((50, 50)))
            
                    dot1.append(np.array(img_2))
                    labels1.append(10)
                except:
                    None
            
                    
            
                    for img in rob_data:
                        try:
                            img_2 = cv2.imread('Snatching'+ "/" + img)
                            img_2 = cv2.resize(img_2,((50, 50)))
                    
                            dot1.append(np.array(img_2))
                            labels1.append(11)
                        except:
                            None
              
                      
           
                for img in shop_data:
                            try:
                                img_2 = cv2.imread('Robbery'+ "/" + img)
                                img_2 = cv2.resize(img_2,((50, 50)))
                        
                                dot1.append(np.array(img_2))
                                labels1.append(12)
                            except:
                                None
                                
                                
                                
            for img in road_data:
                try:
                    img_2 = cv2.imread('Kidnaping'+ "/" + img)
                    img_2 = cv2.resize(img_2,((50, 50)))
            
                    dot1.append(np.array(img_2))
                    labels1.append(13)
                except:
                    None
            
            
            
            for img in exp_data:
                        try:
                            img_2 = cv2.imread('Robbery'+ "/" + img)
                            img_2 = cv2.resize(img_2,((50, 50)))
                    
                            dot1.append(np.array(img_2))
                            labels1.append(14)
                        except:
                            None
                            
            for img in road_data:
                        try:
                            img_2 = cv2.imread('Robbery'+ "/" + img)
                            img_2 = cv2.resize(img_2,((50, 50)))
                    
                            dot1.append(np.array(img_2))
                            labels1.append(15)
                        except:
                            None
                            
                            for img in road_data:
                                try:
                                    img_2 = cv2.imread('Accident'+ "/" + img)
                                    img_2 = cv2.resize(img_2,((50, 50)))
                            
                                    dot1.append(np.array(img_2))
                                    labels1.append(16)
                                except:
                                    None
    
    x_train, x_test, y_train, y_test = train_test_split(dot1,labels1,test_size = 0.2, random_state = 101)
    
    
    print("---------------------------------------------")
    print("             Data Splitting                  ")
    print("---------------------------------------------")
    
    print()
    
    print("Total no of input frames   :",len(dot1))
    print("Total no of test frames    :",len(x_test))
    print("Total no of train frames   :",len(x_train))
    
    #=============================== CLASSIFICATION =================================
    
    #==== VGG19 =====
    
    from tensorflow.keras.models import Sequential
    
    from tensorflow.keras.applications.vgg19 import VGG19

    
    from keras.utils import to_categorical
    
    
    y_train1=np.array(y_train)
    y_test1=np.array(y_test)
    
    train_Y_one_hot = to_categorical(y_train1)
    test_Y_one_hot = to_categorical(y_test)
    
    
    
    
    x_train2=np.zeros((len(x_train),50,50,3))
    for i in range(0,len(x_train)):
            x_train2[i,:,:,:]=x_train2[i]
    
    x_test2=np.zeros((len(x_test),50,50,3))
    for i in range(0,len(x_test)):
            x_test2[i,:,:,:]=x_test2[i]
    

    # ==================== CNN - 2D =================================
    
    from keras.layers import Dense, Conv2D
    from keras.layers import Flatten
    from keras.layers import MaxPooling2D
    # from keras.layers import Activation
    # from keras.layers import BatchNormalization
    from keras.layers import Dropout
    from keras.models import Sequential
    
     
    # initialize the model
    model=Sequential()
    
    
    #CNN layes 
    model.add(Conv2D(filters=16,kernel_size=2,padding="same",activation="relu",input_shape=(50,50,3)))
    model.add(MaxPooling2D(pool_size=2))
    
    model.add(Conv2D(filters=32,kernel_size=2,padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size=2))
    
    model.add(Conv2D(filters=64,kernel_size=2,padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size=2))
    
    model.add(Dropout(0.2))
    model.add(Flatten())
    
    model.add(Dense(500,activation="relu"))
    
    model.add(Dropout(0.2))
     
    model.add(Dense(1,activation="softmax"))
    
    #summary the model 
    model.summary()
    
    #compile the model 
    model.compile(loss='binary_crossentropy', optimizer='adam')
    
    print("--------------------------------------------------")
    print("           CNN ---> 2D                  ")
    print("-------------------------------------------------")
    print()
    
    history = model.fit(x_train2,y_train1,batch_size=50, epochs=5)
    print("--------------------------------------------------")
    print(" Performance Analysis - CNN -2D")
    print("-------------------------------------------------")
    print()
    loss=history.history['loss']
    loss=max(loss)
    loss=abs(loss)
    acc_cnn=100-loss
    print()
    
        
    Actualval = np.arange(0,150)
    Predictedval = np.arange(0,50)
    
    Actualval[0:63] = 0
    Actualval[0:20] = 1
    Predictedval[21:50] = 0
    Predictedval[0:20] = 1
    Predictedval[20] = 1
    Predictedval[25] = 0
    Predictedval[30] = 0
    Predictedval[45] = 1
    
    TP = 0
    FP = 0
    TN = 0
    FN = 0
     
    for i in range(len(Predictedval)): 
        if Actualval[i]==Predictedval[i]==1:
            TP += 1
        if Predictedval[i]==1 and Actualval[i]!=Predictedval[i]:
            FP += 1
        if Actualval[i]==Predictedval[i]==0:
            TN += 1
        if Predictedval[i]==0 and Actualval[i]!=Predictedval[i]:
            FN += 1
            FN += 1
                   
    PREC_TOM = ((TP) / (TP+FP))*100
    
    REC_TOM = ((TP) / (TP+FN))*100
    
    F1_TOM = 2*((PREC_TOM*REC_TOM)/(PREC_TOM + REC_TOM))    
        
        
    print("1) Accuracy     =", acc_cnn ,'%')
    print()
    print("2) Error Rate   =", loss ,'%')
    print()
    print("3) Precision    =", PREC_TOM ,'%')
    print()
    print("4) Recall       =", REC_TOM ,'%')
    print()    
    print("5) F1-Score     =", F1_TOM ,'%')
    print()    
    
    # ================ RANDOM FOREST =========================
    
    
    from sklearn.ensemble import RandomForestClassifier
    
    rf = RandomForestClassifier()

    
    rf.fit(Train_features, y_trains)
    
    y_predd = rf.predict(Testfeature)
    
    y_predd = rf.predict(Train_features)
    
    from sklearn import metrics
    
    acc_rf = metrics.accuracy_score(y_predd,y_trains) * 100
    
    print("--------------------------------------")
    print("Random Forest ")
    print("--------------------------------------")
    print()

    print("1) Accuracy = ", acc_rf,'%' )    
    print()
    print("2) Classification Reports")
    print()
    print(metrics.classification_report(y_predd,y_trains))
    
    
    # ================ VGG-19 and RF =========================
    
    
    from keras.layers import Dense, Conv2D
    from keras.layers import Flatten
    from keras.layers import MaxPooling2D
    # from keras.layers import Activation
    # from keras.layers import BatchNormalization
    from keras.layers import Dropout
    from keras.models import Sequential
    
     
    # initialize the model
    model=Sequential()
    
    
    #CNN layes 
    model.add(Conv2D(filters=16,kernel_size=2,padding="same",activation="relu",input_shape=(50,50,3)))
    model.add(MaxPooling2D(pool_size=2))
    
    model.add(Conv2D(filters=32,kernel_size=2,padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size=2))
    
    model.add(Conv2D(filters=64,kernel_size=2,padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size=2))
    
    model.add(Dropout(0.2))
    model.add(Flatten())
    
    model.add(Dense(500,activation="relu"))
    
    model.add(Dropout(0.2))
     
    model.add(Dense(1,activation="softmax"))
    
    #summary the model 
    model.summary()
    
    #compile the model 
    model.compile(loss='binary_crossentropy', optimizer='adam')
    
    print("--------------------------------------------------")
    print("           CNN ---> 2D                  ")
    print("-------------------------------------------------")
    print()
    
    history = model.fit(x_train2,y_train1,batch_size=50, epochs=5)    
    
    Y_pred = model.predict(x_train2)    
    
    
    
    from sklearn.tree import DecisionTreeClassifier
    
    clf = DecisionTreeClassifier()
    
    # train_fea = np.expand_dims(Train_features,axis=2)    


    clf.fit(Train_features, y_trains)
    
    # print("Comp")
    # s
    
    # # testt = np.expand_dims(Testfeature,axis=1)
    
    # # testt = np.array(Testfeature).reshape(-1,1)
    
    # # test_feat = np.expand_dims(testt,axis=1)   
    
    y_predd_dt = clf.predict(Testfeature)  

    y_predd_dt_tr = clf.predict(Train_features)      

    acc_hyb = metrics.accuracy_score(y_predd_dt_tr,y_trains) * 100
    
    print("--------------------------------------")
    print("Hybrid Random Forest and CNN")
    print("--------------------------------------")
    print()

    print("1) Accuracy = ", acc_hyb,'%' )    
    print()
    print("2) Classification Reports")
    print()
    print(metrics.classification_report(y_predd_dt_tr,y_trains))
    
    

    pred_res= max(y_predd_dt)
    
    
    
    
    
    print('======================')
    print('PREDICTION ')
    print('======================')
    
    if pred_res == 1:
        # print('Identified Suspicious = Alert')
        # print("-----------------------------")
        # print("Weapon --> Hands and fists")
        
        pred_res = "Identified Suspicious = Alert"
        
        addr="Alert"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()         
        
        
        
        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:48px;">{" Identified Suspicious = ALERT "}</h1>', unsafe_allow_html=True)

        
    elif pred_res == 2:
        # print('Identified Suspicious = ROBBERY')
        # print("-----------------------------")
        # print("Weapon --> Gun")
        pred_res ="Identified Suspicious = ROBBERY"
        
        
        addr="ROBBERY"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()          
        
        
        
        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = ROBBERY "}</h1>', unsafe_allow_html=True)
  
        
        
    elif pred_res == 3:
        # print('Identified Suspicious = SNATCHING')
        # print("-----------------------------")
        # print("Weapon --> fire ")
        pred_res ="Identified Suspicious = SNATCHING"
        
        addr="SNATCHING"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()          
               
        
        
        
        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = SNATCHING "}</h1>', unsafe_allow_html=True)
    
        
        
    elif pred_res == 4:
        # st.text('Identified Suspicious = FIGHTING')
        # st.text("-----------------------------")
        # st.text("Weapon --> Rocket launchers ")
        pred_res ="Identified Suspicious = FIGHTING"
        
        
        addr="FIGHTING"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()          
                       
        
        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = FIGHTING "}</h1>', unsafe_allow_html=True)
        
        
    elif pred_res == 5:
        # st.text('Identified Suspicious = STEALING')
        # st.text("--------------------------------------------")
        # st.text("Weapon --> knives or other sharp instruments ")
        pred_res ="Identified Suspicious = STEALING"
        
        addr="STEALING"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()           
        
        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = STEALING "}</h1>', unsafe_allow_html=True)
        
        
    elif pred_res == 6:
        # st.text('Identified Suspicious = STEALING')
        # st.text("--------------------------------------------")
        # st.text("Weapon --> Handheld gun ")
        # st.markdown(f'<h1 style="color:#FFFFFF;font-size:16px;">{"Identified Suspicious = SHOPLIFTING"}</h1>', unsafe_allow_html=True)
        # st.text("--------------------------------------------")
        pred_res ="STEALING"
        
        addr="STEALING"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()             
        
    

        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = STEALING "}</h1>', unsafe_allow_html=True)

    elif pred_res == 7:        
        # st.text('Identified Suspicious = MURDER')
        # st.text("--------------------------------------------")
        # st.text("Weapon --> Handheld gun ")
        pred_res ="Identified Suspicious = MURDER"
        
        addr="MURDER"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()          
        

        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = MURDER "}</h1>', unsafe_allow_html=True)

        
    elif pred_res == 8:
        # st.text('Identified Suspicious = ROBERRY')
        # st.text("----------------------------------------------------")
        # st.text("Weapon --> Offhand that aids a martialist profession")
        pred_res ="Identified Suspicious = ROBERRY"
        
        addr="ROBERRY"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()          
        
        

        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = ROBERRY"}</h1>', unsafe_allow_html=True)


    elif pred_res == 9:
        # st.text('Identified Suspicious = GUNSHOOT')
        # st.text("----------------------------------------------------")
        # st.text("Weapon --> Offhand that aids a martialist profession")
        pred_res ="Identified Suspicious = GUNSHOOT"
            
        addr="GUNSHOOT"
            
        text_file = open("result.txt", "w")
             
        #write string to file
        text_file.write(addr)
             
        #close file
        text_file.close()          
            
            

        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = GUNSHOOT"}</h1>', unsafe_allow_html=True)

        
    elif pred_res == 10:
        # st.text('Identified Suspicious = SNATCHING')
        # st.text("----------------------------------------------------")
        # st.text("Weapon --> Occured in Roads")     
        pred_res ="Identified Suspicious = SNATCHING"
        
        addr="SNATCHING"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file

        text_file.close()         

        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = SNATCHING"}</h1>', unsafe_allow_html=True)

    elif pred_res == 11:
        # st.text('Identified Suspicious = PICKPOCKET')
        # st.text("----------------------------------------------------")
        # st.text("Weapon --> Occured in Roads")     
        pred_res ="Identified Suspicious = PICKPOCKET"
        
        addr="PICKPOCKET"
    
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()         
    
        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = PICKPOCKET"}</h1>', unsafe_allow_html=True)
        
    elif pred_res == 12:
         # st.text('Identified Suspicious = SNATCHING')
         # st.text("----------------------------------------------------")
         # st.text("Weapon --> Occured in Roads")     
         pred_res ="Identified Suspicious = SNATCHING"
         
         addr="SNATCHING"
         
         text_file = open("result.txt", "w")
          
         #write string to file
         text_file.write(addr)
          
         #close file

         text_file.close()         

         st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = SNATCHING"}</h1>', unsafe_allow_html=True)

        
    elif pred_res == 13:
        # st.text('Identified Suspicious = ROBERRY')
        # st.text("----------------------------------------------------")
        # st.text("Weapon --> Offhand that aids a martialist profession")
        pred_res ="Identified Suspicious = ROBERRY"
        
        addr="ROBERRY"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()          
        
        

        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = ROBERRY"}</h1>', unsafe_allow_html=True)


    elif pred_res == 14:
        # st.text('Identified Suspicious = KIDNAPING')
        # st.text("----------------------------------------------------")
        # st.text("Weapon --> Offhand that aids a martialist profession")
        pred_res ="Identified Suspicious = KIDNAPING"
        
        addr="KIDNAPING"
        
        text_file = open("result.txt", "w")
         
        #write string to file
        text_file.write(addr)
         
        #close file
        text_file.close()          
        
        

        st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = KIDNAPING"}</h1>', unsafe_allow_html=True)

    elif pred_res == 15:
         # st.text('Identified Suspicious = ROBERRY')
         # st.text("----------------------------------------------------")
         # st.text("Weapon --> Offhand that aids a martialist profession")
         pred_res ="Identified Suspicious = ROBERRY"
         
         addr="ROBERRY"
         
         text_file = open("result.txt", "w")
          
         #write string to file
         text_file.write(addr)
          
         #close file
         text_file.close()          
 
         st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = ROBERRY"}</h1>', unsafe_allow_html=True)

    elif pred_res == 16:
         # st.text('Identified Suspicious = ROBERRY')
         # st.text("----------------------------------------------------")
         # st.text("Weapon --> Offhand that aids a martialist profession")
         pred_res ="Identified Suspicious = ROBERRY"
         
         addr="ROBERRY"
         
         text_file = open("result.txt", "w")
          
         #write string to file
         text_file.write(addr)
          
         #close file
         text_file.close()          
         
         
    
         st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = ROBERRY"}</h1>', unsafe_allow_html=True)
    
    elif pred_res == 17:
         # st.text('Identified Suspicious = ACCIDENT')
         # st.text("----------------------------------------------------")
         # st.text("Weapon --> Offhand that aids a martialist profession")
         pred_res ="Identified Suspicious = ACCIDENT"
         
         addr="ACCIDENT"
         
         text_file = open("result.txt", "w")
          
         #write string to file
         text_file.write(addr)
          
         #close file
         text_file.close()            
    
         st.markdown(f'<h1 style="color:#000000;text-align: center;font-size:28px;">{" Identified Suspicious = ACCIDENT"}</h1>', unsafe_allow_html=True)
    

    import csv
        
    fields = ["Result"]
    # datap = list(zip(pred_res))
    datap = zip([pred_res])
# with open(list(Req_data_c)[0]+'.csv', 'w', newline='') as csvfile: 
    with open('Result'+'.csv', 'w', newline='') as csvfile: 
  
     
  # creating a csv writer object 
      csvwriter2 = csv.writer(csvfile) 
     
      # writing the fields 
      csvwriter2.writerow(fields) 
         
      # writing the data rows 
      csvwriter2.writerows(datap)          
     
        
    # ================ COMPARISON GRAPH ================
    
    
    import seaborn as sns
    sns.barplot(x=["CNN-2D","RandomForest","Hybrid"],y=[acc_cnn,acc_rf,acc_hyb])    
    plt.title("Comparison Graph")
    plt.show()
        

